import { initDynamicFormBuilder } from './dynamicFormBuilder.js';

document.addEventListener('DOMContentLoaded', () => {
    initDynamicFormBuilder('form-builder-container');
});
