export function initDynamicFormBuilder(formContainerId) {
    const formContainer = document.getElementById(formContainerId);
    if (!formContainer) {
        console.error(`Form container with id ${formContainerId} not found.`);
        return;
    }

    const form = document.createElement('form');
    form.id = 'dynamic-form';
    formContainer.appendChild(form);

    const addTextInputButton = createButton('Add Text Input', () => addField('text'));
    const addCheckboxButton = createButton('Add Checkbox', () => addField('checkbox'));
    const addRadioButton = createButton('Add Radio Button', () => addField('radio'));
    const addTextAreaButton = createButton('Add Text Area', () => addField('textarea'));
    const addSelectButton = createButton('Add Select Dropdown', () => addField('select'));
    const addDateButton = createButton('Add Date Input', () => addField('date'));
    const addNumberInputButton = createButton('Add Number Input', () => addField('number'));
    const addPasswordInputButton = createButton('Add Password Input', () => addField('password'));
    const addEmailInputButton = createButton('Add Email Input', () => addField('email'));
    const addColorPickerButton = createButton('Add Color Picker', () => addField('color'));
    const addRangeSliderButton = createButton('Add Range Slider', () => addField('range'));

    formContainer.appendChild(addTextInputButton);
    formContainer.appendChild(addCheckboxButton);
    formContainer.appendChild(addRadioButton);
    formContainer.appendChild(addTextAreaButton);
    formContainer.appendChild(addSelectButton);
    formContainer.appendChild(addDateButton);
    formContainer.appendChild(addNumberInputButton);
    formContainer.appendChild(addPasswordInputButton);
    formContainer.appendChild(addEmailInputButton);
    formContainer.appendChild(addColorPickerButton);
    formContainer.appendChild(addRangeSliderButton);

    function createButton(text, onClick) {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = text;
        button.addEventListener('click', onClick);
        return button;
    }

    function addField(type) {
        const fieldWrapper = document.createElement('div');
        fieldWrapper.className = 'form-field';

        let field;
        switch (type) {
            case 'text':
                field = document.createElement('input');
                field.type = 'text';
                field.name = 'text-input[]';
                break;
            case 'checkbox':
                field = document.createElement('input');
                field.type = 'checkbox';
                field.name = 'checkbox[]';
                break;
            case 'radio':
                field = document.createElement('input');
                field.type = 'radio';
                field.name = 'radio[]';
                break;
            case 'textarea':
                field = document.createElement('textarea');
                field.name = 'textarea[]';
                break;
            case 'select':
                field = document.createElement('select');
                field.name = 'select[]';
                const option1 = document.createElement('option');
                option1.value = 'option1';
                option1.textContent = 'Option 1';
                const option2 = document.createElement('option');
                option2.value = 'option2';
                option2.textContent = 'Option 2';
                field.appendChild(option1);
                field.appendChild(option2);
                break;
            case 'date':
                field = document.createElement('input');
                field.type = 'date';
                field.name = 'date[]';
                break;
            case 'number':
                field = document.createElement('input');
                field.type = 'number';
                field.name = 'number[]';
                break;
            case 'password':
                field = document.createElement('input');
                field.type = 'password';
                field.name = 'password[]';
                break;
            case 'email':
                field = document.createElement('input');
                field.type = 'email';
                field.name = 'email[]';
                break;
            case 'color':
                field = document.createElement('input');
                field.type = 'color';
                field.name = 'color[]';
                break;
            case 'range':
                field = document.createElement('input');
                field.type = 'range';
                field.name = 'range[]';
                break;
        }

        const removeButton = document.createElement('button');
        removeButton.type = 'button';
        removeButton.className = 'remove-btn';
        removeButton.textContent = 'Remove';
        removeButton.addEventListener('click', () => form.removeChild(fieldWrapper));

        fieldWrapper.appendChild(field);
        fieldWrapper.appendChild(removeButton);
        form.appendChild(fieldWrapper);
    }
}
