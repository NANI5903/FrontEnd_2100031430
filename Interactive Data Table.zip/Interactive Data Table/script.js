const dataTable = document.getElementById('data-table');
const tableBody = document.getElementById('table-body');
const pagination = document.getElementById('pagination');
const searchInput = document.getElementById('search-input');

let currentPage = 1;
const rowsPerPage = 10;
let data = [
    { name: 'John Doe', age: 20, city: 'New York' },
    { name: 'Jane Smith', age: 22, city: 'Los Angeles' },
    { name: 'Michael Johnson', age: 21, city: 'Chicago' },
    { name: 'Emily Brown', age: 25, city: 'Houston' },
    { name: 'Emma Wilson', age: 23, city: 'Phoenix' },
    { name: 'William Taylor', age: 24, city: 'Philadelphia' },
    { name: 'Olivia Martinez', age: 19, city: 'San Antonio' },
    { name: 'James Anderson', age: 26, city: 'San Diego' },
    { name: 'Sophia Thomas', age: 27, city: 'Dallas' },
    { name: 'Daniel Jackson', age: 28, city: 'San Jose' },
    { name: 'Isabella White', age: 29, city: 'Austin' },
    { name: 'Mason Harris', age: 30, city: 'Jacksonville' },
    { name: 'Amelia Clark', age: 31, city: 'Indianapolis' },
    { name: 'Ethan Lewis', age: 32, city: 'San Francisco' },
    { name: 'Abigail Lee', age: 33, city: 'Columbus' },
    { name: 'Alexander Walker', age: 34, city: 'Charlotte' },
    { name: 'Ava Perez', age: 35, city: 'Fort Worth' },
    { name: 'Benjamin Hall', age: 36, city: 'Detroit' },
    { name: 'Chloe Green', age: 37, city: 'El Paso' },
    { name: 'Elijah Roberts', age: 38, city: 'Seattle' },
    { name: 'Charlotte Hill', age: 39, city: 'Denver' },
    
];


renderTable(data);


searchInput.addEventListener('input', handleSearch);

function renderTable(data) {
    
    tableBody.innerHTML = '';

  
    const start = (currentPage - 1) * rowsPerPage;
    const end = start + rowsPerPage;
    const paginatedData = data.slice(start, end);

    paginatedData.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.name}</td>
            <td>${item.age}</td>
            <td>${item.city}</td>
        `;
        tableBody.appendChild(row);
    });

   
    renderPagination(data.length);
}

function renderPagination(totalRows) {
    pagination.innerHTML = '';

    const totalPages = Math.ceil(totalRows / rowsPerPage);

    for (let i = 1; i <= totalPages; i++) {
        const button = document.createElement('button');
        button.textContent = i;
        button.classList.add('pagination-button');
        if (i === currentPage) {
            button.disabled = true;
        }
        button.addEventListener('click', () => {
            currentPage = i;
            renderTable(data);
        });
        pagination.appendChild(button);
    }
}

function handleSearch() {
    const searchTerm = searchInput.value.toLowerCase();
    const filteredData = data.filter(item =>
        item.name.toLowerCase().includes(searchTerm) ||
        item.age.toString().includes(searchTerm) ||
        item.city.toLowerCase().includes(searchTerm)
    );
    renderTable(filteredData);
}


dataTable.addEventListener('click', event => {
    if (event.target.tagName === 'TH') {
        const column = event.target.dataset.column;
        if (column) {
            data.sort((a, b) => {
                if (event.target.dataset.type === 'number') {
                    return a[column] - b[column];
                } else {
                    return a[column].localeCompare(b[column]);
                }
            });
            renderTable(data);
        }
    }
});

